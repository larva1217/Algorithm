package binarytree;

public class BinaryTree {
	BTNode root;
	
	public BinaryTree() {
		root = null;
	}
	public BinaryTree(String data) {
		root = new BTNode(null, data, null);;
	}
	public BinaryTree(BinaryTree lTree, String data, BinaryTree rTree) {
		root = new BTNode(lTree.root, data, rTree.root);
	}
	
	public boolean isEmpty() {
		if(root==null) {
			return true;
		}else {
			return false;
		}
	}
	
	public BinaryTree leftSubTree() {
		// 현재 Tree의 왼쪽 서브트리를 반환
		BinaryTree leftTree = new BinaryTree();
		leftTree.root = root.Lchild;
		return leftTree;
	}
	
	public BinaryTree rightSubTree() {
		// 현재 Tree의 오른쪽 서브트리를 반환
		BinaryTree rightTree = new BinaryTree();
		rightTree.root = root.Rchild;
		return rightTree;
	}
	
	public String rootData() {
		// root Node의 데이터를 반환
		return root.data;
	}
	
	public void printTree() {
		printTree(root);
	}
	
	private void printTree(BTNode t) {
		// 중위 순회를 이용하여 이진트리에 입력된 수식을 출력	
		if(t==null) {
			return;
		}
		if((t.Lchild==null)&&(t.Rchild==null)) {
			System.out.print(t.data);
		}else {
			System.out.print("(");
			printTree(t.Lchild);
			System.out.print(" "+t.data+" ");
			printTree(t.Rchild);
			System.out.print(")");
		}
	}
	
	public int calculate() {
		return theCalculate(root);
	}
	
	private int theCalculate(BTNode t) {
		// 재귀 알고리즘을 이용하여 이진 트리에 입력된 수식을 계산
		if(t.Lchild==null && t.Rchild==null) {
			return Integer.parseInt(t.data);
		}
		
		int left = theCalculate(t.Lchild);
		int right = theCalculate(t.Rchild);
			
		switch(t.data) {
			case "+": return left+right;
			case "-": return left-right;
			case "*": return left*right;
			case "/": return left/right;
			default: return 0;
		}
	}
	
}

