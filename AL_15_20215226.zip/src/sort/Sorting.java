package sort;

public class Sorting {
	public static void mergeSort(int[] a) {
		int[] temp = new int[a.length];
		theMergeSort(a, temp, 0, a.length-1);
	}
	
	private static void theMergeSort(int[] a, int[] temp, int left, int right) {
		if(left<right) {
			int middle = (left+right)/2;
			theMergeSort(a,temp,left,middle);
			theMergeSort(a,temp,middle+1,right);
			merge(a,temp,left,middle,middle+1,right);
		}
	}
	
	private static void merge(int[] a, int[] temp, int m, int p, int q, int n) {
		int t=m;
		int numElements=n-m+1;
		while(m<=p && q<=n) {
			if(a[m]<a[q]) {
				temp[t++] = a[m++];
			}else {
				temp[t++] = a[q++];
			}
		}
		while(m<=p) {
			temp[t++]=a[m++];
		}
		while(q<=n) {
			temp[t++]=a[q++];
		}
		for(int i=0; i<numElements; i++, n--) {
			a[n]=temp[n];
		}
	}
}
