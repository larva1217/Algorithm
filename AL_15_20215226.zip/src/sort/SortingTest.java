package sort;

public class SortingTest {

	public static void main(String[] args) {
		int[] test1 = {0,5,2,1,7,8,9,14};
		Sorting.mergeSort(test1);
		for(int i = 0; i < test1.length; i++)
			System.out.print(test1[i] + ", ");
		System.out.println();
	}

}
