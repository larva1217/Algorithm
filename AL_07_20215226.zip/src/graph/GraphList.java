package graph;


public class GraphList {
    int n;  
    int e;
    Node[] header;  

   
    public GraphList(int i) {
        n = i;
        e = 0;
        header = new Node[i];
    }

    
    public void insertEdge(int i, int j) {
        Node newNode = new Node();
        newNode.vertex = j;
        newNode.link = header[i];
        header[i] = newNode;

        newNode = new Node();
        newNode.vertex = i;
        newNode.link = header[j];
        header[j] = newNode;

        e++; 
    }

   
    public void removeEdge(int i, int j) {
        Node prev = null;
        Node curr = header[i];

        while (curr != null) {
            if (curr.vertex == j) {
                if (prev == null) {
                    header[i] = curr.link;  
                } else {
                    prev.link = curr.link; 
                }
                break;  
            }
            prev = curr;
            curr = curr.link;
        }

       
        prev = null;
        curr = header[j];

        
        while (curr != null) {
            if (curr.vertex == i) {
                if (prev == null) {
                    header[j] = curr.link; 
                } else {
                    prev.link = curr.link; 
                }
                break;  
            }
            prev = curr;
            curr = curr.link;
        }

        e--; 
    }

    
    public int[] adjacency(int u) {
        int count = 0;
        Node temp = header[u];

       
        while (temp != null) {
            count++;
            temp = temp.link;
        }

        
        int[] adj = new int[count];
        temp = header[u];
        int index = 0;
        while (temp != null) {
            adj[index++] = temp.vertex;
            temp = temp.link;
        }

        return adj;
    }

 
    public void bfs(int v) {
        Queue q = new Queue();
        boolean[] visited = new boolean[n];

        System.out.print("BFS: ");
        visited[v] = true;
        q.enqueue(v);

        while (!q.isEmpty()) {
            int u = (int) q.dequeue();
            System.out.print(u + " ");

            
            Node temp = header[u];
            while (temp != null) {
                if (!visited[temp.vertex]) {
                    visited[temp.vertex] = true;
                    q.enqueue(temp.vertex);
                }
                temp = temp.link;
            }
        }
        System.out.println();
    }

   
    public void dfs(int v) {
        Stack s = new Stack();
        boolean[] visited = new boolean[n];

        System.out.print("DFS: ");
        s.push(v);
        visited[v] = true;

        while (!s.empty()) {
            int u = (int) s.pop();
            System.out.print(u + " ");

           
            Node temp = header[u];
            while (temp != null) {
                if (!visited[temp.vertex]) {
                    s.push(temp.vertex);
                    visited[temp.vertex] = true;
                }
                temp = temp.link;
            }
        }
        System.out.println();
    }
}

