package graph;

public class Graph {
	int n; // Number of vertices
	int e; // Number of edges
	int[][] weight;

	public Graph(int noOfVertices) {
		n = noOfVertices;
		e = 0;
		weight = new int[n][n];
	}

	public void insertEdge(int i, int j) {
		if(weight[i][j]==0) {
			weight[i][j]=1;
			weight[j][i]=1;
			e++;
		}
	}

	public void removeEdge(int i, int j) {
		if(weight[i][j]==1) {
			weight[i][j]=0;
			weight[j][i]=0;
			e--;
		}
	}

	public int[] adjacency(int u) {
		int[] adj;
		int count = 0;
		for(int i=0; i<n; i++) {
			if(weight[u][i]==1) {
				count++;
			}
		}
		adj = new int[count];
		int index=0;
		for(int i=0; i<count; i++) {
			if(weight[u][i]==1) {
				adj[index++] = i;
			}
		}
		return adj;
	}
	
	public void bfs(int v) {
		Stack s = new Stack();
		Queue q = new Queue();
	    boolean[] visited = new boolean[n];
	    
	    for (int i = 0; i < n; i++) {
	        visited[i] = false; 
	    }
	    
	    q.enqueue(v);  
	    visited[v] = true; 
	    
	    System.out.print("BFS: ");
	    
	    while (!q.isEmpty()) {
	        int u = (int) q.dequeue(); 
	        System.out.print(u + " ");  
	        
	        
	        for (int i = 0; i < n; i++) {
	            if (weight[u][i] == 1 && !visited[i]) { 
	                q.enqueue(i);
	                visited[i] = true;
	            }
	        }
	    }
	    System.out.println(); 
		
	}	
	
	public void dfs(int v) {
		 Stack s = new Stack();
		    boolean[] visited = new boolean[n];
		    
		    for (int i = 0; i < n; i++) {
		        visited[i] = false; 
		    }
		    
		    s.push(v); 
		    visited[v] = true; 
		    
		    System.out.print("DFS: ");
		    
		    while (!s.empty()) {
		        int u = (int) s.pop(); 
		        System.out.print(u + " ");  
		        
		        // 인접한 모든 정점을 스택에 삽입
		        for (int i = 0; i < n; i++) {
		            if (weight[u][i] == 1 && !visited[i]) { 
		                s.push(i);
		                visited[i] = true; 
		            }
		        }
		    }
		    System.out.println(); 
	}
	
	public void dfsComponent() {
		boolean[] visited = new boolean[n];
	    
	    for (int i = 0; i < n; i++) {
	        if (!visited[i]) { 
	            System.out.print("Component: ");
	            dfs(i, visited); 
	            System.out.println(); 
	        }
	    }
	}

	
	private void dfs(int v, boolean[] visited) {
	    visited[v] = true;
	    System.out.print(v + " ");
	    
	    for (int i = 0; i < n; i++) {
	        if (weight[v][i] == 1 && !visited[i]) {
	            dfs(i, visited);  
	        }
	    }
	}
}
