package digraph;


public class DiGraph {
	int n; // Number of vertices
	int e; // Number of edges
	int[][] weight;

	public DiGraph(int noOfVertices) {
		n = noOfVertices;
		e = 0;
		weight = new int[n][n];
	}

	public void insertEdge(int i, int j) {
		if(weight[i][j]==0) {
			weight[i][j]=1;
			e++;
		}
	}

	public void removeEdge(int i, int j) {
		 if(weight[i][j] != 0) { 
	            weight[i][j] = 0; 
	            e--; 
	     }
	}

	public int[] adjacency(int u) {
	     int count=0;
	        for (int v=0; v<n; v++) {
	            if (weight[u][v] != 0) {
	                count++; 
	            }
	        }

	        int[] arr = new int[count]; 
	        int index = 0;
	        for (int v=0; v<n; v++) {
	            if (weight[u][v] != 0) {
	                arr[index++]=v; 
	            }
	        }
	     return arr; 
	}
	
	public void bfs(int v) {
		 System.out.println("BFS");
	        Queue q = new Queue();
	        boolean[] visited = new boolean[n];

	        visited[v] = true;
	        q.enqueue(v);

	        while (!q.isEmpty()) {
	            int u = (int) q.dequeue();
	            System.out.print(u + ", ");

	            for (int w = 0; w < n; w++) {
	                if (weight[u][w] != 0 && !visited[w]) {
	                    visited[w] = true;
	                    q.enqueue(w);
	                }
	            }
	        }

	        System.out.println(); 
	}
	
	public void dfs(int v) {
		 System.out.println("DFS");
	        boolean[] visited = new boolean[n];
	        Stack s = new Stack();
	        s.push(v);

	        while (!s.empty()) {
	            int u = (int) s.pop();
	            if (!visited[u]) {
	                visited[u] = true;
	                System.out.print(u + ", ");
	            }

	            for (int w = 0; w < n; w++) { 
	                if (weight[u][w] != 0 && !visited[w]) {
	                    s.push(w);
	                }
	            }
	        }
	        System.out.println();
	    }
	}
	
	
	



