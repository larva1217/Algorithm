package heap;

public class Heap {
	private int count;
	private int size;
	private int[] itemArray;
	
	public Heap() {
		count = 0;
		size = 64;
		itemArray = new int[size];
	}
	
	public static Heap makeHeap(int[] origArray) {
		// origArray를 바탕으로 max heap 생성
		Heap h = new Heap();
		h.count = origArray.length-1;
		
		for(int i = 1; i < origArray.length; i++) {
			h.itemArray[i] = origArray[i];  //heap 0 사용 안함
		}
		
		//최대힙
		for (int i = 1; i < h.count; i++) {
	        for (int j = i; j > 1; j--) {
	            int parent = j / 2;
	            if (h.itemArray[parent] < h.itemArray[j]) {
	                int temp = h.itemArray[parent];
	                h.itemArray[parent] = h.itemArray[j];
	                h.itemArray[j] = temp;
	            }
	        }
	    }
		return h;
	}
	
	public void insert(int newItem) {
		 if (count >= size - 1) {
	            return;
	        }
	        count++;
	        itemArray[count] = newItem;

	        int i = count;
	        while (i > 1 && itemArray[i] > itemArray[i / 2]) {
	            int temp = itemArray[i];
	            itemArray[i] = itemArray[i / 2];
	            itemArray[i / 2] = temp;
	            i = i / 2;
	        }
	}
	
	public void printHeap() {
		for(int i = 1; i <= count; i++) 
			System.out.print(itemArray[i] + " ");
		System.out.println();
	}
	
	public int delete() {
		if(count==0) {
			return -100;
		}else {
	        int maxItem = itemArray[1]; 
	        itemArray[1] = itemArray[count]; 
	        count--; 

	        int i = 1; 
	        while (i * 2 <= count) { 
	            int left = i * 2;
	            int right = left + 1;
	            int max = left; 

	            
	            if (right <= count && itemArray[right] > itemArray[left]) {
	                max = right;
	            }

	            if (itemArray[i] >= itemArray[max]) {
	                break;
	            }

	            int temp = itemArray[i];
	            itemArray[i] = itemArray[max];
	            itemArray[max] = temp;
	            i = max;
	        }

	        return maxItem; 
	    }
	}
	
	public static void main(String[] args) {
		Heap h = new Heap();
		int[] origArray = {0,50,55,60,30,70,90,25,80,40,45};
		h = Heap.makeHeap(origArray);
		h.printHeap();
		
		
		h.delete();
		h.delete();
		h.delete();
		
		h.printHeap();
	}
	
}

