package sort;

public class Sorting {
	public static void insertionSort(int[] a) {
		int k, j;
		boolean move;
		for(int i = 1; i < a.length; i++) {
			k = a[i];
			j = i;
			if(a[j-1] > k) { 
				move = true;
			}
			else {
				move = false;
			}
			while(move) {
				a[j] = a[j-1];
				j--;
				if(j>0 && a[j-1]>k) {
					move = true;
				}else {
					move = false;
				}
			}
			a[j] = k;
		}
	}
	
	public static void selectionSort(int[] a) {
		int i, j, min;
		for(i = 0; i < a.length; i++) {
			for(j = i+1, min = i; j < a.length; j++) {
				if(a[j] < a[min]) {
					min = j;
				}
			}
			swap(a, min, i);
		}
	}
	
	public static void bubbleSort(int[] a) {
		int i, j;
		for(i = a.length-1; i > 0; i--) {
			for(j = 0; j < i; j++) {
				if(a[j] > a[j+1]) {
					swap(a, j, j+1);
				}
			}
		}
	}
	
	private static void swap(int[] a, int j, int k) {
		int temp = a[j];
		a[j] = a[k];
		a[k] = temp;
	}
	
}
