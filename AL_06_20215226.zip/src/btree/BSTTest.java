package btree;

public class BSTTest {
	public static void main(String args[]) {

		BinarySearchTree t1 = new BinarySearchTree();
		t1.BSTinsert("S");
		t1.BSTinsert("J");
		t1.BSTinsert("B");
		t1.BSTinsert("D");
		t1.BSTinsert("U");
		t1.BSTinsert("M");
		t1.BSTinsert("R");
		t1.BSTinsert("Q");
		t1.BSTinsert("A");
		t1.BSTinsert("G");
		t1.BSTinsert("E");
		
		t1.print();
		
		BinarySearchTree Small = new BinarySearchTree();
		BinarySearchTree Large = new BinarySearchTree();
		
		t1.BSTsplit("C", Small, Large);
		
		Small.print();
		Large.print();


		
	}
}
