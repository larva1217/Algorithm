package heap;

public class Heap {
	private int count;
	private int size;
	private int[] itemArray;
	
	public Heap() {
		count = 0;
		size = 64;
		itemArray = new int[size];
	}
	
	public static Heap makeHeap(int[] origArray) {
		// origArray를 바탕으로 max heap 생성
		Heap h = new Heap();
		h.count = origArray.length;
		
		for(int i = 0; i < origArray.length; i++) {
			h.itemArray[i+1] = origArray[i];
		}
		
		for (int i = 1; i < h.count; i++) {
	        for (int j = i; j > 1; j--) {
	            int parent = j / 2;
	            if (h.itemArray[parent] < h.itemArray[j]) {
	                int temp = h.itemArray[parent];
	                h.itemArray[parent] = h.itemArray[j];
	                h.itemArray[j] = temp;
	            }
	        }
	    }
		return h;
	}
	
	public void insert(int newItem) {
		// newItem을 max heap에 맞게 추가
		if(count > size) {
			return;
		}
		count++;
		itemArray[count+1] = newItem;
		
		int i=count;
		while(i>1 && itemArray[i]>itemArray[i/2]) {
			int temp = itemArray[i];
			itemArray[i] = itemArray[i/2];
			itemArray[i/2] = temp;
			i = i/2;
		}
	}
	
	public void printHeap() {
		for(int i = 1; i <= count; i++) 
			System.out.print(itemArray[i] + " ");
		System.out.println();
	}
	
}

