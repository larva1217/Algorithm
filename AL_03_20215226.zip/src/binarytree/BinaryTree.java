package binarytree;

import java.util.*;

class BinaryTree {

	BTNode root;

	public BinaryTree() {
		root = null;
	}

	public BinaryTree(BinaryTree ltree, String data, BinaryTree rtree) {
		root = new BTNode(ltree.root, data, rtree.root);
	}

	public boolean isEmpty() {
		return (root == null);
	}

	public BinaryTree leftSubTree() {
		BinaryTree ltree = new BinaryTree();
		ltree.root = root.Lchild;
		return ltree;
	}

	public BinaryTree rightSubTree() {
		BinaryTree rtree = new BinaryTree();
		rtree.root = root.Rchild;
		return rtree;
	}

	public String rootData() {
		return root.data;
	}

	public void inorder() {
		System.out.println("[Inorder]");
		theInorder(root);
		System.out.println();
		
		// 아래 내용은 실습 과제입니다. (주석 해제 후 inorderIter 메소드에 코드 작성)
		
		System.out.println("[InorderIter]");
		inorderIter();
		System.out.println();
		
	}

	public void preorder() {
		System.out.println("[Preorder]");
		thePreorder(root);
		System.out.println();
		
		// 아래 내용은 실습 과제입니다. (주석 해제 후 preorderIter 메소드에 코드 작성)
	
		System.out.println("[PreorderIter]");
		preorderIter();
		System.out.println();
		
	}

	public void postorder() {
		System.out.println("[Postorder]");
		thePostorder(root);
		System.out.println();
	}

	private void theInorder(BTNode t) {
		// 재귀 알고리즘을 사용하여 중위 순회 구현
		if(t != null) {
			theInorder(t.Lchild);
			System.out.print(t.data);
			theInorder(t.Rchild);
		}
	}

	private void thePreorder(BTNode t) {
		// 재귀 알고리즘을 사용하여 전위 순회 구현
		if(t != null) {
			System.out.print(t.data);
			thePreorder(t.Lchild);
			thePreorder(t.Rchild);
		}
	}

	private void thePostorder(BTNode t) {
		// 재귀 알고리즘을 사용하여 후위 순회 구현
		if(t != null) {
			thePostorder(t.Lchild);
			thePostorder(t.Rchild);
			System.out.print(t.data);
		}
	}

	private void inorderIter() {
		Stack s = new Stack();
		BTNode p = root;

		// 스택과 반복문을 사용하여 중위 순회 구현
		while(p!=null || !s.empty()) {
			while(p!=null) {
				s.push(p);
				p=p.Lchild;
			}
			
			p=(BTNode)s.pop();
			System.out.print(p.data + " ");
			
			p=p.Rchild;
		}
		
	
	
	}

	private void preorderIter() {
		Stack s = new Stack();
		BTNode p = root;

		s.push(p);
		
		while(!s.empty()) {
			p=(BTNode)s.pop();
			System.out.print(p.data);
			
			if(p.Rchild != null) {
				s.push(p.Rchild);
			}
			if(p.Lchild != null){
				s.push(p.Lchild);
			}
		}
	}

	public void levelorder() {
		BTNode p;
		Queue q = new Queue();
		System.out.println("[Level order]");
		
		// 큐와 반복문을 사용하여 레벨 순회 구현
		q.enqueue(root);
		
		while(!q.isEmpty()) {
			p=(BTNode)q.dequeue();
			System.out.print(p.data + " ");
			
			if(p.Lchild!=null) {
				q.enqueue(p.Lchild);
			}
			if(p.Rchild!=null) {
				q.enqueue(p.Rchild);
			}
		}
		
		System.out.println();
	}

	public BinaryTree copy() {
		BinaryTree newTree = new BinaryTree();
		newTree.root = theCopy(root);
		return newTree;
	}

	private BTNode theCopy(BTNode t) {
		// 재귀 알고리즘을 사용하여 트리 복사 구현
		if(t==null) {
			return null;
		}
		BTNode newNode = new BTNode(t.Lchild,t.data,t.Rchild);
		newNode.Lchild = theCopy(t.Lchild);
		newNode.Rchild = theCopy(t.Rchild);
		    
		return newNode;  
	}

	public boolean equals(BinaryTree tr) {
		return theEqual(this.root, tr.root);
	}

	private boolean theEqual(BTNode s, BTNode t) {
		// 재귀 알고리즘을 사용하여 트리 비교 구현
		// 같은 트리일 경우 True 반환
		if(s==null && t==null) {
			return true;
		}
		if(s==null||t==null) {
			return false;
		}
		return s.data.equals(t.data) && theEqual(s.Lchild, t.Lchild) && theEqual(s.Rchild, t.Rchild);
	}

}