package recursion;

public class Fibo {

	public static final int MAX_N=10;
	public static void main(String[] args) {
		for(int i=0; i<=MAX_N; i++) 
			System.out.println(fib(i));
		
		System.out.println("--------------------------");
		
		for(int i=0; i<=MAX_N; i++) 
			System.out.println(fibIter(i));
	}
	
	public static long fib(int n) {
		if(n==0) {
			return 0;
		}else if(n==1) {
			return 1;
		}else{
			return fib(n-1)+fib(n-2);
		}
		
	}
	
	public static long fibIter(int n) {
		if(n==0) {
			return 0;
		}
		if(n==1) {
			return 1;
		}
		long fib1=0;
		long fib2=1;
		long result=0;
		
		for(int i=2; i<=n; i++) {
			result = fib1+fib2;
			fib1=fib2;
			fib2=result;
		}
		return result;
	}

}
