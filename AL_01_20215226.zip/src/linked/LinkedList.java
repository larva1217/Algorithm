package linked;

public class LinkedList {
	private int length;
	private ListNode first;
	
	public LinkedList() {
		length = 0;
		first = null;
	}
	
	public int length() {
		return length;
	}
	
	public void addFirst(String name) {
		ListNode newNode = new ListNode(name);
		newNode.setLink(first);
		first=newNode;
		length++;
	}
	
	public void insert(String name, ListNode target) {
		if(target != null) {
			ListNode newNode = new ListNode(name);
			newNode.setLink(target.getLink());
			target.setLink(newNode);
			length++;
		}
	}
	
	public ListNode searchNode(String name) {
		ListNode Node = first;
		while(Node != null) {
			if(Node.getName().equals(name)) {
				return Node;
			}
			Node = Node.getLink();
		}
		return null;
	}
	
	public void delete(ListNode p) {
		if(first==null || p==null) {
			return;
		}
		
		if(first==p) {
			first=first.getLink();
		}else {
			ListNode Node = first;
			while(Node.getLink() != null && Node.getLink() != p) {
				Node = Node.getLink();
			}
			if(Node.getLink() == p) {
				Node.setLink(p.getLink());
			}
		}
		length--;
	}
	
	public void print() {
		System.out.println("----------------");
		ListNode Node = first;
		while(Node != null) {
			System.out.println(Node.getName());
			Node=Node.getLink();
		}
		System.out.println("----------------");
	}
	
}


