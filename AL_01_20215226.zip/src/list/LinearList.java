package list;

class LinearList {
	 private String strArray[];
	 private int size;
	 public static int MAX = 100;
	 
	 public LinearList() {
		 size = 0;
		 strArray = new String[MAX];
	 }

	 public boolean isEmpty(){
		 if(size==0) {
			 return true;
		 }else {
			 return false;
		 }
	 }
	 
	 public int length(){
		return size;
	 }
	 
	 public String retrieve(int i){
		 if(i>=0&&i<size) {
			 return strArray[i];
		 }
		 else {
			 return null;
		 }
	 }
	 
	 public void delete(int i){
		 if(i>=0&&i<size) {
			 for(int j=i; j<size; j++) {
				 strArray[j]=strArray[j+1];
			 }
			 strArray[size-1]=null;
			 size--;
		 }else {
			 System.out.println("삭제할수없습니다.");
		 }
		 
	 }
	 
	 public void insert(int i, String str){
		 if(i>=0&&i<=size&&size<MAX) {
			 for(int j=size; j>i; j--) {
				 strArray[j]=strArray[j-1];
			 }
			 strArray[i]=str;
			 size++;
		 }else {
			 System.out.println("추가할수없습니다.");
		 }
		 
	 }
	 
	 public void printArray(){
		 for(int i=0; i<size; i++) {
			 System.out.println("["+i+"]"+":"+strArray[i]);
		 }
	 }
}

