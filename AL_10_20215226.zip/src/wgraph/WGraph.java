package wgraph;

public class WGraph {
	int n;
	int e;
	int[][] weight;
	
	public WGraph(int nOfVertices) {
		n = nOfVertices;
		e = 0;
		weight = new int[n][n];
		for (int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				if(i == j)
					weight[i][j] = 0;
				else
					weight[i][j] = 9999;
			}
		}
		
	}

	public void insertEdge(int i, int j, int w) {
		if(weight[i][j]==9999) {
			weight[i][j]=w;
			weight[j][i]=w;
			e++;
		}
	}
	
	public void removeEdge(int i, int j, int w) {
		// 이곳에 코드 작성
		// 제거된 edge는 9999의 값을 가짐
		if(weight[i][j]==0) {
			weight[i][j]=9999;
			weight[j][i]=9999;
			e--;
		}
	}
	
	public Edge[] spanningTree() {
		  Edge[] T = new Edge[n - 1]; 
		    MinHeap edgeList = new MinHeap();
		    UnionFind uf = new UnionFind(n);
		    for (int i = 0; i < n; i++) {
		        for (int j = i + 1; j < n; j++) {
		            if (weight[i][j] != 9999) {
		                edgeList.insert(new Edge(i, j, weight[i][j]));
		            }
		        }
		    }

		    int Tptr = 0;

		    while (Tptr < n - 1 && edgeList.numberElements() > 0) {
		        Edge edge = (Edge) edgeList.delete(); 
		        int u = edge.tail;
		        int v = edge.head;
		        if (!uf.find(u, v)) {
		            uf.union(u, v);
		            T[Tptr++] = edge;
		        }
		    }
		    return T;
	}
	
	public Edge[] prim(int i) {		
		  Edge[] T = new Edge[n - 1];
		    MinHeap edgeList = new MinHeap();
		    int Tptr = 0;
		    boolean[] visited = new boolean[n];
		    visited[i] = true;
		  
		    for (int j = 0; j < n; j++) {
		        if (weight[i][j] != 9999) {
		            edgeList.insert(new Edge(i, j, weight[i][j]));
		        }
		    }

		    while (Tptr < n - 1 && edgeList.numberElements() > 0) {
		        Edge edge = (Edge) edgeList.delete();
		        int u = edge.head;
		        int v = edge.tail;

		        if (!visited[v]) {
		            visited[v] = true;
		            T[Tptr++] = edge;
		            for (int j = 0; j < n; j++) {
		                if (!visited[j] && weight[v][j] != 9999) {
		                    edgeList.insert(new Edge(v, j, weight[v][j]));
		                }
		            }
		        }
		    }

		    return T;
	}
}

