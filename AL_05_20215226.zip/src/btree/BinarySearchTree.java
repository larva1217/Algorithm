package btree;

public class BinarySearchTree {
private TreeNode rootNode;
    
    public TreeNode BSTsearch(String K) {
    	// 문자열 k에 해당하는 TreeNode를 찾아서 반환
    	TreeNode t = rootNode;
    	int result;
    	
    	while(t!=null) {
    		if((result = K.compareTo(t.key)) < 0) {
    			t=t.Lchild;
    		}
    		else if(result==0){
    			return t;
    		}
    		else {
    			t = t.Rchild;
    		}
    	}
    	return t;
    }

    public void BSTinsert(String K) {
        // BinarySearchTree에 새로운 TreeNode 추가
    	TreeNode newNode = new TreeNode();
    	newNode.key=K;
    	
    	if(rootNode==null) {
    		rootNode=newNode;
    		return;
    	}
    	
    	TreeNode t = rootNode;
    	TreeNode p;
    	
    	while(t != null) {
    		p = t;
    		
    		if(K.compareTo(t.key) < 0) {
        		t = t.Lchild;
        		if(t==null) {
        			p.Lchild=newNode;
        		}
        	}
    		else if(K.compareTo(t.key) > 0){
    			t = t.Rchild;
    			if(t==null) {
    				p.Rchild=newNode;
    			}
    		}
    		else {
    			return;
    		}
    	}
    	
    }

    private TreeNode maxNode(TreeNode root) {
        TreeNode p = root;
        if (p.Rchild == null) return p;
        else return maxNode(p.Rchild);
    }

   private TreeNode delete(TreeNode root, String K) {
        // BinarySearchTree에서 문자열 k를 갖는 TreeNode를 삭제
	   if(root == null) {
		   return null;
	   }
	   
	   int result = K.compareTo(root.key);
	   
	   if(result<0) {
		   root.Lchild = delete(root.Lchild, K);
	   }
	   else if(result > 0) {
		   root.Rchild = delete(root.Rchild, K);
	   }
	   else {
		   if(root.Lchild==null && root.Rchild == null) {
			   return null;
		   }
		   if(root.Lchild == null) {
			   return root.Rchild;
		   }else if(root.Rchild == null) {
			   return root.Lchild;
		   }
		   
		   TreeNode newNode = maxNode(root.Lchild);
		   root.key=newNode.key;
		   root.Lchild = delete(root.Lchild, newNode.key);
	   }
	   
	   return root;
	  
    }

    public void BSTdelete(String K) {
        rootNode = delete(rootNode, K);
    }
  
    private void printNode(TreeNode n) {
        // BinarySearchTree 출력
    	if(n != null) {
    		System.out.print("(");
    		printNode(n.Lchild);
    		System.out.print(n.key);
    		printNode(n.Rchild);
    		System.out.print(")");
    	}
    }
    
    public void print() {
        printNode(rootNode);
        System.out.println();
    }
}
