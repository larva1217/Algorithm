package sort;

public class Sorting {
	
	public static void quickSort(int[] a) {
		theQuickSort(a, 0, a.length - 1);
	}
	
	private static void theQuickSort(int[] a, int left, int right) {
		// 재귀 알고리즘 및 partition 메소드를 사용하여 퀵소트 구현
		int p;
		if(left>right) {
			return;
		}
		p = partition(a,left,right);
		theQuickSort(a,left,p-1);
		theQuickSort(a,p+1,right);
	}
	
    private static int partition(int[] a, int left, int right) {
        int middle = (left+right)/2;
    	int pivot = a[middle]; 
    	
    	a[middle]=a[left];
    	a[left]=pivot;
        int p = left;
        
        for (int k=left+1; k<=right; k++) { 
            if (a[k]<pivot) {
                p++;
                swap(a,p,k);
            }
        }
        swap(a,left,p); 
        return p; 
    }
	
	public static void heapSort(int[] a) {
		// heapify 메소드를 사용하여 힙소트 구현
		int n = a.length;
		
		for(int i=n/2-1; i>=1; i--) {
			heapify(a,n,i);
		}
		for(int i=n-1; i>=0; i--) {
			swap(a,0,i);
			heapify(a,i,0);
		}
	}
	
	private static void heapify(int[] a, int h, int m) {
		int largest = m; 
        int left = 2*m+1; 
        int right = 2*m+2;

        
        if (left<h && a[left]>a[largest]) {
            largest=left;
        }

        if (right<h && a[right]>a[largest]) {
            largest=right;
        }
        if (largest!=m) {
            swap(a,m,largest);
            heapify(a,h,largest);
        }
	}
	
	private static void swap(int[] a, int j, int k) {
		int temp = a[j];
		a[j] = a[k];
		a[k] = temp;
	}
}
