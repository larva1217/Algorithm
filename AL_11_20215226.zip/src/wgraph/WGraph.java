package wgraph;

public class WGraph {
	int n;
	int e;
	int[][] weight;
	
	public WGraph(int nOfVertices) {
		n = nOfVertices;
		e = 0;
		weight = new int[n][n];
		for (int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				if(i == j)
					weight[i][j] = 0;
				else
					weight[i][j] = 9999;
			}
		}
		
	}
	
	public WGraph() {
		n = 0;
		e = 0;
	}
	
	public void insertEdge(int i, int j, int w) {
		if(weight[i][j] == 9999)
			e++;
		weight[i][j] = w;
	}
	
	public void removeEdge(int i, int j, int w) {
		if(weight[i][j] != 9999)
			e--;
		weight[i][j] = 9999;
	}
	
	public int[] shortestPath(int v) {
		boolean s[] = new boolean[n];
		int dist[] = new int[n];
		int u = 0;
		// 이곳에 코드 작성
		for(int i=0; i<n; i++) {
			s[i]=false;
			dist[i]=weight[v][i];
		}
		
		s[v]=true;
		dist[v]=0;
		
		for(int k=1; k<n; k++) {
			int min=9999;     
			for (int i=0; i<n; i++) {
				if (!s[i] && dist[i]<min) {
					min=dist[i];
					u=i;
				}
			}

	        s[u]=true;
	        
	        for (int w=0; w<n; w++) {
	        	if (!s[w] && weight[u][w]!=9999 && dist[u]+weight[u][w]<dist[w]) {
	        		dist[w]=dist[u]+weight[u][w];
	            }
	        }
	   }
	        
		return dist;
	}

	public int[] negativePath(int v) {
		int dist[] = new int[n];
		// 이곳에 코드 작성
		for(int i=0; i<n; i++) {
			dist[i]=weight[v][i];
		}
		
		for (int k=1; k<n-1; k++) {  
			for (int u=0; u<n; u++) {  
				if (u!=v && dist[u]!=9999) {  
					for (int i=0; i<n; i++) {  
						if (weight[u][i]!=9999 && dist[u]+weight[u][i]<dist[i]) {
							dist[i]=dist[u]+weight[u][i];
		                }
		            }
		         }
		    }
		}
		
		return dist;
	}
	
	public int[][] allShortestPath() {
		int[][] distance = weight;
		int[][] distanceP;
		int k, i, j;
		// 이곳에 코드 작성
		distanceP=weight;
		for (i=0; i<n; i++) {
	        for (j=0; j<n; j++) {
	        	distanceP[i][j]=distance[i][j];
	        }
	    }

	    for (k=0; k<n; k++) {
	        for (i=0; i<n; i++) {
	            for (j=0; j<n; j++) {
	                if (distanceP[i][k]!=9999 && distanceP[k][j]!=9999) {
	                    if (distanceP[i][j]>distanceP[i][k]+distanceP[k][j]) {
	                        distanceP[i][j]=distanceP[i][k]+distanceP[k][j];
	                    }
	                }
	            }
	        }
	    }
		return distance;
	}
}
